#!/bin/sh
# DanmakuNotify 诊断脚本（随包安装到 /var/jb/usr/share/DanmakuNotify/dm-diag.sh）
#
# 用法（root 终端，一条命令）：
#     sh /var/jb/usr/share/DanmakuNotify/dm-diag.sh
#
# 它回答三个从未被确认过的事实，输出很短，便于截图/抄录：
#   ① 设备是 arm64 还是 arm64e
#   ② 本插件 dylib 是 arm64(00000000) 还是 arm64e(00000002)
#   ③ 同目录里「能正常工作」的插件，它们的 dylib 是哪个架构、过滤器怎么写

PATH=/var/jb/usr/bin:/var/jb/bin:/usr/bin:/bin:/usr/sbin:/sbin
export PATH
DL=/var/jb/Library/MobileSubstrate/DynamicLibraries

# od 直接读 Mach-O 头：offset4=cputype  offset8=cpusubtype
arch() { od -An -tx4 -j4 -N8 "$1" 2>/dev/null | while read a b; do echo "cputype=$a cpusubtype=$b"; done; }

echo "===== ① 设备 ====="
echo "machine    = $(sysctl -n hw.machine 2>/dev/null)"
echo "cpusubtype = $(sysctl -n hw.cpusubtype 2>/dev/null)   (2=arm64e / 0=arm64)"
echo
echo "===== ② 本插件 ====="
echo "DanmakuNotify.dylib  $(arch "$DL/DanmakuNotify.dylib")"
echo
echo "===== ③ 其它插件（对比用，各取前 4 个） ====="
n=0
for f in "$DL"/*.dylib; do
	case "$f" in *DanmakuNotify*) continue ;; esac
	n=$((n + 1))
	[ "$n" -gt 4 ] && break
	echo "${f##*/}  $(arch "$f")"
done
echo
echo "----- 一个正常插件的过滤器写法 -----"
n=0
for f in "$DL"/*.plist; do
	case "$f" in *DanmakuNotify*) continue ;; esac
	n=$((n + 1))
	[ "$n" -gt 1 ] && break
	cat "$f" 2>/dev/null
done
echo
echo "----- 本插件的过滤器 -----"
cat "$DL/DanmakuNotify.plist" 2>/dev/null
echo
echo "===== 结束 ====="
exit 0
